INSTALLATION:
	To run the provided package, please follow the instructions for your operating system:
Note: following steps require you to have Python 3.x downloaded and installed on your machine.
For Windows:
	Open command prompt as administrator
	Update the pip install �python -m pip install �upgrade pip�
	To install matplotlib use �python -m pip matplotlib�
	To install numpy use �python -m pip numpy�
For OS X:
	Open the terminal
	Update the pip install �pip install �upgrade pip� or python3 get-pip.py
	To install matplotlib use �pip install matplotlib�
	To install numpy use �pip install numpy�
For Linux:
	Open the terminal
	Install python3 with �sudo apt-get install python3�
	Install pip with �sudo apt-get install python3-pip�
	To install matplotlib use �python -m pip install -U matplotlib�
	To Install numpy use �python -m install numpy�
RUN PROGRAM:
	To run the program, navigate to the directory /TSP/ and use �python3 TSP_main.py�. You
can switch between the three data sets with a command line argument, for example, �python3
TSP_main.py sahara� will run the program using the Sahara city data. This works with Sahara, Uruguay
and Canada as arguments. Any unknown command defaults to Sahara.

---
By:
Scott Jennings
George Neonakis
Elliot Moors